if you want to set threshold of image you can set threshold in threshold function
if your image has more noise or reflection then set threshold value higher than 12000
if you increase more value the rice will started to fade away 
Threshold function is at line no 36
if you want to set the area condition you can set in reigion probes loops at line no 88
area varies from rice to rice 
RUN file on pycharm 
or run it directly change folder and excel sheet name to the required one